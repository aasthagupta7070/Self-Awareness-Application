package com.Project2.personaken;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;

public
class progress extends AppCompatActivity {

    @Override
    protected
    void onCreate ( Bundle savedInstanceState ) {
        super.onCreate ( savedInstanceState );
        setContentView ( R.layout.activity_progress );
    }
}