package com.Project2.personaken;

import android.os.Bundle;

public
class Repor extends Dashboard {

    @Override
    public
    void onCreate ( Bundle savedInstanceState ) {
        super.onCreate ( savedInstanceState );
        setContentView ( R.layout.activity_repor );
    }
}