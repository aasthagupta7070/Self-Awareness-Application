package com.Project2.personaken;

import android.os.Bundle;

public
class blog extends Dashboard {

    @Override
    public
    void onCreate ( Bundle savedInstanceState ) {
        super.onCreate ( savedInstanceState );
        setContentView ( R.layout.activity_blog );
    }
}